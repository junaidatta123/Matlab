function visualize_digit_prediction(model, directory, digit, israndom)
    if (nargin<4)
        israndom=1;
    end
    base_path = fullfile(directory, num2str(digit));
    image_files = dir(fullfile(base_path, '*.jpg'));
    if (israndom)
    	random_image = image_files(randi(length(image_files)));
    else
    	random_image = image_files(1);
    end
    disp(['Selected image: ', random_image.name, ', for digit: ', num2str(digit)]);
    
    image_path = fullfile(base_path, random_image.name);
    input_image = imread(image_path);
    input_image = imresize(input_image, [28 28]);
    if size(input_image, 3) == 3
        input_image = rgb2gray(input_image);
    end
    input_array = single(input_image) / 255.0;
    
    % Get model predictions
    [~, scores] = classify(model, input_array);
    predictions = scores * 100;
    
    % Create a figure with two subplots
    figure;
    subplot(1, 2, 1);
    imshow(input_image);
    title('Input Image');
    
    subplot(1, 2, 2);
    bar(0:9, predictions);
    xlabel('Digit Prediction');
    ylabel('Prediction Probability (%)');
    title('Model Predictions');
    ylim([0 100]);
    
    % Add percentage labels on top of each bar
    text(0:9, predictions, cellstr(num2str(predictions', '%.1f%%')), ...
         'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
    
    % Print the predicted digit
    [~, predicted_digit] = max(predictions);
    disp(['The model predicts this image is a ', num2str(predicted_digit-1)]);
    disp(['Confidence: ', num2str(predictions(predicted_digit), '%.2f'), '%']);
    disp(' ');
end