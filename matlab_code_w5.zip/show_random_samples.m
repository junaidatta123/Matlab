function show_random_samples(base_dir, digit)
    target_dir = fullfile(base_dir, num2str(digit));
    if ~exist(target_dir, 'dir')
        disp(['Directory ', target_dir, ' does not exist.']);
        return;
    end
    
    files = dir(fullfile(target_dir, '*.jpg'));
    if length(files) < 4
        disp(['Not enough images in ', target_dir, '. Found only ', num2str(length(files)), ' images.']);
        return;
    end
    
    random_samples = randsample(files, 4);
    
    figure;
    for i = 1:4
        img_path = fullfile(target_dir, random_samples(i).name);
        img = imread(img_path);
        
        subplot(2, 2, i);
        imshow(img);
        title(['Sample ', num2str(i)]);
    end
end