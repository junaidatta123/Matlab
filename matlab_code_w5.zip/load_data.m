function [images, labels] = load_data(directory)
    % Loads images and labels from the specified directory for digits 0-9.
    % Parameters:
    % - directory (str): The base directory containing digit-classified subdirectories.
    % Returns:
    % - images (ndarray): 4D array of loaded images.
    % - labels (categorical): Array of corresponding labels (digits).

    images = [];
    labels = [];
    MAX_PER_DIGIT = 999;  % Maximum number of images to load per digit

    % Loop through the directories for each digit (0-9)
    for digit = 0:9
        digit_dir = fullfile(directory, num2str(digit));  % Path to the digit folder
        count = 0;  % Track number of images per digit

        % Get the list of image files in the directory
        img_files = dir(fullfile(digit_dir, '*.jpg'));

        for i = 1:length(img_files)
            % Get the full path of the image
            img_path = fullfile(digit_dir, img_files(i).name);

            % Read the image and convert to grayscale if needed
            img = imread(img_path);
            if size(img, 3) == 3  % Convert RGB to grayscale if necessary
                img = rgb2gray(img);
            end

            % Resize the image to 28x28
            img = imresize(img, [28 28]);

            % Normalize the image to [0, 1]
            img = single(img) / 255;

            % Add a channel dimension (28x28x1)
            img = reshape(img, [28 28 1]);

            % Append the image and corresponding label to the arrays
            images = cat(4, images, img);  % Concatenate along the 4th dimension
            labels = [labels; digit];  % Append the label as a row

            count = count + 1;
            if count == MAX_PER_DIGIT
                break;
            end
        end
    end

    % Convert labels to categorical format
    labels = categorical(labels);
end
