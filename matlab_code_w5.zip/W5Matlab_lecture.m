clear
clc

% unzip("digits_dataset.zip")

%%
% Define path 
training_dir_path = 'training_set';

% Set random seed for reproducibility
rng(42);

% Load and prepare training data
[X_train, y_train] = load_data(training_dir_path);

% Show random samples
show_random_samples(training_dir_path, 5);

%%

% Load and prepare validation data
validation_dir_path = 'validation_set';
[X_validation, y_validation] = load_data(validation_dir_path);

%%

disp(['Amount of training data: ', num2str(size(X_train, 4))]);
disp(['Amount of validation data: ', num2str(size(X_validation, 4))]);

[img_height, img_width, ~, ~] = size(X_train);
disp(['Image shape: ', num2str(img_width), 'x', num2str(img_height)]);

%%

% Define the CNN
layers = [
    imageInputLayer([img_height img_width 1])
    convolution2dLayer(3, 32, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(7, 'Stride', 7)
    flattenLayer
    fullyConnectedLayer(10)
    softmaxLayer
    classificationLayer];

%%


% Set up training parameters
options = trainingOptions('sgdm', ...
    'InitialLearnRate', 0.01, ...
    'MaxEpochs', 20, ...
    'MiniBatchSize', 16, ...
    'Shuffle', 'every-epoch', ...
    'ValidationData', {X_validation, y_validation}, ... 
    'Plots', 'training-progress', ...
    'Verbose', false);
%%
% Train the network
CNNmodel = trainNetwork(X_train, categorical(y_train), layers, options);

%%
% After training, evaluate the model on the validation set
[YPred, scores] = classify(CNNmodel, X_validation);
validation_accuracy = sum(YPred == categorical(y_validation)) / numel(y_validation);
disp(['Final Validation Accuracy: ', num2str(validation_accuracy * 100), '%']);

%%
% Save the model
% save('my_model.mat', 'model');
% disp('Training finished!');

% Visualize trained kernels in the first layer
%visualize_neural_network_fx(model, validation_dir_path, 1);

% Prediction samples
%%
visualize_digit_prediction(CNNmodel, validation_dir_path, 3);

%%
visualize_digit_prediction(CNNmodel, validation_dir_path, 9);

%%
visualize_digit_prediction(CNNmodel, validation_dir_path, 5);


%%
%visualize_digit_prediction(CNNmodel, validation_dir_path, 5);

%%
visualize_digit_prediction(CNNmodel, validation_dir_path, 4);
%%
visualize_digit_prediction(CNNmodel, validation_dir_path, 9);
%%
visualize_digit_prediction(CNNmodel, validation_dir_path, 0);
