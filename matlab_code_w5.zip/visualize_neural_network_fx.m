function visualize_neural_network_fx(model, directory, digit)
    base_path = fullfile(directory, num2str(digit));
    image_files = dir(fullfile(base_path, '*.jpg'));
    random_image = image_files(randi(length(image_files)));
    disp(['Selected image: ', random_image.name, ', for digit: ', num2str(digit)]);
    
    image_path = fullfile(base_path, random_image.name);
    input_image = imread(image_path);
    input_image = imresize(input_image, [28 28]);
    if size(input_image, 3) == 3
        input_image = rgb2gray(input_image);
    end
    input_image = single(input_image) / 255.0;
    
    % Get feature maps from the first convolutional layer
    feature_maps = activations(model, input_image, 2);
    
    % Get pooled feature maps
    pooled_feature_maps = activations(model, input_image, 4);
    
    % Plot the original image
    figure;
    imshow(input_image);
    title('Original Image');
    
    % Display the convolutional feature maps
    figure;
    num_filters = size(feature_maps, 3);
    for i = 1:num_filters
        subplot(4, 8, i);
        imshow(feature_maps(:,:,i), []);
        title(['Conv Kernel ', num2str(i)]);
    end
    sgtitle('Convolutional Feature Maps');
    
    % Display the pooled feature maps
    figure;
    num_pooled_filters = size(pooled_feature_maps, 3);
    for i = 1:num_pooled_filters
        subplot(4, 8, i);
        imshow(pooled_feature_maps(:,:,i), []);
        title(['Pooled image ', num2str(i)]);
    end
    sgtitle('Pooled Feature Maps');
end