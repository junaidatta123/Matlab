% Load the image
file_name = "part.png";
A_color = imread(file_name);
A_g = rgb2gray(A_color);
A = double(A_g);
whos A
disp(A(2, 3));
disp(A);
imshow(A, [0, 255], 'InitialMagnification', 6000);

% Blurring kernel
K = ones(3, 3) / 9;
R = im_filtering(A, K);
R_g = uint8(R);
compare_images(A, R)

% Padding
Ap = zeros(size(A, 1) + 2, size(A, 2) + 2);
Ap(2 : end - 1, 2 : end - 1) = A;

Rp = im_filtering(Ap, K);
Rp_g = uint8(Rp);  
compare_images(A, Rp_g)